<?php
// PHPMailer classes ko include karna
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// PHPMailer autoload file ko include karna
require 'vendor/autoload.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Form data ko variables me store karna
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $number = $_POST['number'];
    $message = $_POST['message'];

    // PHPMailer object create karna
    $mail = new PHPMailer(true);

    try {
        // SMTP settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // SMTP server (aap apne SMTP server ka host yaha daalein)
        $mail->SMTPAuth = true;
        $mail->Username = 'rajpatel8726@gmail.com'; // SMTP username
        $mail->Password = 'wanx jngy xoor aqrc';    // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Encryption type (TLS)
        $mail->Port = 587; // SMTP port (TLS ke liye 587)

        // Sender aur recipient settings
        $mail->setFrom('rajpatel8726@gmail.com', 'Your Name'); // Apna email aur naam yaha daalein
        $mail->addAddress('rajpatel8726@gmail.com', 'Recipient Name'); // Recipient email

        // Email content settings
        $mail->isHTML(true);
        $mail->Subject = 'New Contact Us Message';
        $mail->Body    = "<h3>Contact Details</h3>
                          <p><strong>Name:</strong> $fullname</p>
                          <p><strong>Email:</strong> $email</p>
                          <p><strong>Phone:</strong> $number</p>
                          <p><strong>Message:</strong><br>$message</p>";
        
        // Email send karna
        $mail->send();
        echo "<script>alert('Your message has been sent successfully!');</script>";
    } catch (Exception $e) {
        echo "<script>alert('Failed to send email. Error: {$mail->ErrorInfo}');</script>";
    }
}
?>
